export interface SKUData {
  sku: string;
  title: string;
  content: string;
  imageUrls: string;
  productCategories: string;
  status: string; // "Publish", "Draft", "Private"
  stock: number;
  mainCategory: string;
  subcategory: string;
  subSubcategory: string;
  subSubSubcategory: string;
  has2Images: boolean;
  hasContent: boolean;
  isSellable: boolean;
}

export interface CategoryStats {
  name: string;
  total: number;
  published: number;
  draft: number;
  private: number;
  unpublished: number;
  sellable: number;
  publishedAndSellable: number;
  skusWith2Images: number;
  skusWithContent: number;
  skusWithContentAndImages: number;
  slaAdherence: number;
}

export interface SummaryStats {
  totalSKUs: number;
  publishedSKUs: number;
  draftSKUs: number;
  privateSKUs: number;
  unpublishedSKUs: number;
  sellableSKUs: number;
  publishedAndSellable: number;
  skusWith2Images: number;
  skusWithContent: number;
  skusWithContentAndImages: number;
  newSKUsThisUpload: number;
  avgStock: number;
  imageCompletionRate: number;
  contentRate: number;
  slaAdherenceRate: number;
  publishRate: number;
}

export interface Issue {
  type: 'error' | 'warning' | 'success' | 'info';
  title: string;
  description: string;
  count?: number;
  impact?: string;
}

export interface UploadRecord {
  id: string;
  fileName: string;
  uploadDate: string;
  totalSKUs: number;
  newSKUsCount: number;
  skuList: string[];
}

export interface SKURecord {
  sku: string;
  status: string;
  stock: number;
  mainCategory: string;
  subcategory: string;
  imageUrls: string;
  content: string;
  has2Images: boolean;
  hasContent: boolean;
  isSellable: boolean;
  lastSeen: string;
}

export interface SKUMovement {
  sku: string;
  previousStatus: string;
  currentStatus: string;
  previousStock: number;
  currentStock: number;
  mainCategory: string;
  subcategory: string;
  movementType: 'status_change' | 'stock_change' | 'new' | 'removed';
}

export interface AnalyticsData {
  summary: SummaryStats;
  categoryBreakdown: {
    mainCategories: CategoryStats[];
    subcategories: CategoryStats[];
    subSubcategories: CategoryStats[];
  };
  newSKUBreakdown: {
    mainCategories: CategoryStats[];
    subcategories: CategoryStats[];
  };
  issues: Issue[];
  newSKUs: string[];
  newSKUData: SKUData[];
  movements: SKUMovement[];
  uploadHistory: UploadRecord[];
}