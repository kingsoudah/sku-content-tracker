import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { AlertTriangle, CheckCircle, Info, AlertCircle } from 'lucide-react';
import { Issue } from '../types';

interface IssueHighlightsProps {
  issues: Issue[];
}

export function IssueHighlights({ issues }: IssueHighlightsProps) {
  const getIcon = (type: Issue['type']) => {
    switch (type) {
      case 'error':
        return <AlertCircle className="w-5 h-5 text-red-500" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-amber-500" />;
      case 'success':
        return <CheckCircle className="w-5 h-5 text-emerald-500" />;
      case 'info':
        return <Info className="w-5 h-5 text-blue-500" />;
    }
  };

  const getBgColor = (type: Issue['type']) => {
    switch (type) {
      case 'error':
        return 'bg-red-50 border-red-200';
      case 'warning':
        return 'bg-amber-50 border-amber-200';
      case 'success':
        return 'bg-emerald-50 border-emerald-200';
      case 'info':
        return 'bg-blue-50 border-blue-200';
    }
  };

  return (
    <Card className="bg-white border border-slate-200 shadow-sm">
      <CardHeader className="border-b border-slate-100">
        <CardTitle className="text-lg font-semibold text-slate-800">Insights & Issues</CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        <div className="space-y-3">
          {issues.map((issue, index) => (
            <div
              key={index}
              className={`flex items-start gap-3 p-4 rounded-lg border ${getBgColor(issue.type)}`}
            >
              <div className="flex-shrink-0 mt-0.5">{getIcon(issue.type)}</div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-semibold text-slate-800">{issue.title}</h4>
                  {issue.count !== undefined && (
                    <span className="text-sm font-bold text-slate-700">{issue.count}</span>
                  )}
                </div>
                <p className="text-sm text-slate-600 mt-1">{issue.description}</p>
                {issue.impact && (
                  <p className="text-xs text-slate-500 mt-2 font-medium">
                    Impact: {issue.impact}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}