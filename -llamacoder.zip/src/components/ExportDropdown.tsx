import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Download, FileSpreadsheet, FileText, AlertTriangle, CheckCircle, ChevronDown, X } from 'lucide-react';
import { AnalyticsData, SKUData } from '../types';
import { 
  exportAnalyticsToCSV, 
  exportSummaryReport, 
  exportNewSKUsList, 
  exportCategoryBreakdown,
  exportUnpublishedSKUs,
  exportSLAReport
} from '../utils/exporter';

interface ExportDropdownProps {
  analyticsData: AnalyticsData;
  rawData: SKUData[];
  fileName: string;
}

export function ExportDropdown({ analyticsData, rawData, fileName }: ExportDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);

  const baseFileName = fileName.replace(/\.[^/.]+$/, '');

  const exportOptions = [
    {
      label: 'Full Analytics Report',
      description: 'Complete analytics with all metrics and breakdowns',
      icon: <FileSpreadsheet className="w-4 h-4" />,
      action: () => exportAnalyticsToCSV(analyticsData, baseFileName),
      color: 'text-blue-600'
    },
    {
      label: 'Executive Summary',
      description: 'Key metrics and recommended actions',
      icon: <FileText className="w-4 h-4" />,
      action: () => exportSummaryReport(analyticsData, baseFileName),
      color: 'text-violet-600'
    },
    {
      label: 'SLA Adherence Report',
      description: 'SLA compliance by category',
      icon: <CheckCircle className="w-4 h-4" />,
      action: () => exportSLAReport(analyticsData, baseFileName),
      color: 'text-emerald-600'
    },
    {
      label: 'Category Breakdown',
      description: 'Detailed category performance',
      icon: <FileSpreadsheet className="w-4 h-4" />,
      action: () => exportCategoryBreakdown(analyticsData, baseFileName),
      color: 'text-cyan-600'
    },
    {
      label: 'New SKUs List',
      description: `${analyticsData.newSKUs.length} new SKUs detected`,
      icon: <FileText className="w-4 h-4" />,
      action: () => exportNewSKUsList(analyticsData, baseFileName),
      color: 'text-violet-600'
    },
    {
      label: 'Unpublished SKUs',
      description: 'Draft and unpublished items needing attention',
      icon: <AlertTriangle className="w-4 h-4" />,
      action: () => exportUnpublishedSKUs(rawData, baseFileName),
      color: 'text-amber-600'
    }
  ];

  return (
    <div className="relative">
      <Button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white"
      >
        <Download className="w-4 h-4" />
        Export Reports
        <ChevronDown className="w-4 h-4" />
      </Button>

      {isOpen && (
        <>
          <div 
            className="fixed inset-0 z-40"
            onClick={() => setIsOpen(false)}
          />
          <Card className="absolute right-0 mt-2 w-80 z-50 bg-white shadow-xl border border-slate-200">
            <CardHeader className="pb-2 border-b border-slate-100">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-semibold text-slate-800">Export Options</CardTitle>
                <button
                  onClick={() => setIsOpen(false)}
                  className="text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </CardHeader>
            <CardContent className="p-2">
              <div className="space-y-1">
                {exportOptions.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      option.action();
                      setIsOpen(false);
                    }}
                    className="w-full flex items-start gap-3 p-3 rounded-lg hover:bg-slate-50 transition-colors text-left"
                  >
                    <div className={`flex-shrink-0 mt-0.5 ${option.color}`}>
                      {option.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-slate-800">{option.label}</p>
                      <p className="text-xs text-slate-500 truncate">{option.description}</p>
                    </div>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}