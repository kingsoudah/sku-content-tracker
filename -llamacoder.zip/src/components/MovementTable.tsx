import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { SKUMovement } from '../types';
import { ArrowUpRight, ArrowDownRight, Plus, Minus, RefreshCw } from 'lucide-react';

interface MovementTableProps {
  movements: SKUMovement[];
}

export function MovementTable({ movements }: MovementTableProps) {
  if (movements.length === 0) {
    return (
      <Card className="bg-white border border-slate-200 shadow-sm">
        <CardContent className="py-12 text-center">
          <RefreshCw className="w-12 h-12 text-slate-300 mx-auto mb-4" />
          <p className="text-slate-500">No SKU movements detected since last upload.</p>
          <p className="text-sm text-slate-400 mt-2">Upload another CSV to track changes.</p>
        </CardContent>
      </Card>
    );
  }

  const getMovementIcon = (type: SKUMovement['movementType']) => {
    switch (type) {
      case 'new':
        return <Plus className="w-4 h-4 text-emerald-500" />;
      case 'removed':
        return <Minus className="w-4 h-4 text-red-500" />;
      case 'status_change':
        return <ArrowUpRight className="w-4 h-4 text-blue-500" />;
      case 'stock_change':
        return <RefreshCw className="w-4 h-4 text-amber-500" />;
    }
  };

  const getMovementLabel = (type: SKUMovement['movementType']) => {
    switch (type) {
      case 'new':
        return <span className="px-2 py-1 bg-emerald-100 text-emerald-700 text-xs rounded-full">New SKU</span>;
      case 'removed':
        return <span className="px-2 py-1 bg-red-100 text-red-700 text-xs rounded-full">Removed</span>;
      case 'status_change':
        return <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full">Status Change</span>;
      case 'stock_change':
        return <span className="px-2 py-1 bg-amber-100 text-amber-700 text-xs rounded-full">Stock Change</span>;
    }
  };

  const getStatusBadge = (status: string) => {
    const colors: Record<string, string> = {
      'Published': 'bg-emerald-100 text-emerald-700',
      'Draft': 'bg-amber-100 text-amber-700',
      'Private': 'bg-purple-100 text-purple-700',
      'Unpublished': 'bg-red-100 text-red-700',
      'New': 'bg-cyan-100 text-cyan-700'
    };
    return (
      <span className={`px-2 py-1 text-xs rounded-full ${colors[status] || 'bg-slate-100 text-slate-700'}`}>
        {status}
      </span>
    );
  };

  const newCount = movements.filter(m => m.movementType === 'new').length;
  const removedCount = movements.filter(m => m.movementType === 'removed').length;
  const statusChangeCount = movements.filter(m => m.movementType === 'status_change').length;
  const stockChangeCount = movements.filter(m => m.movementType === 'stock_change').length;

  return (
    <div className="space-y-6">
      {/* Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-emerald-50 border border-emerald-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Plus className="w-5 h-5 text-emerald-600" />
              <span className="text-2xl font-bold text-emerald-700">{newCount}</span>
            </div>
            <p className="text-sm text-emerald-600 mt-1">New SKUs</p>
          </CardContent>
        </Card>
        <Card className="bg-red-50 border border-red-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Minus className="w-5 h-5 text-red-600" />
              <span className="text-2xl font-bold text-red-700">{removedCount}</span>
            </div>
            <p className="text-sm text-red-600 mt-1">Removed SKUs</p>
          </CardContent>
        </Card>
        <Card className="bg-blue-50 border border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <ArrowUpRight className="w-5 h-5 text-blue-600" />
              <span className="text-2xl font-bold text-blue-700">{statusChangeCount}</span>
            </div>
            <p className="text-sm text-blue-600 mt-1">Status Changes</p>
          </CardContent>
        </Card>
        <Card className="bg-amber-50 border border-amber-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <RefreshCw className="w-5 h-5 text-amber-600" />
              <span className="text-2xl font-bold text-amber-700">{stockChangeCount}</span>
            </div>
            <p className="text-sm text-amber-600 mt-1">Stock Changes</p>
          </CardContent>
        </Card>
      </div>

      {/* Movement Table */}
      <Card className="bg-white border border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-100">
          <CardTitle className="text-lg font-semibold text-slate-800">
            Movement Details ({movements.length} total)
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200">
                  <th className="text-left py-3 px-4 text-xs font-semibold text-slate-600">Type</th>
                  <th className="text-left py-3 px-4 text-xs font-semibold text-slate-600">SKU</th>
                  <th className="text-left py-3 px-4 text-xs font-semibold text-slate-600">Category</th>
                  <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">Previous Status</th>
                  <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">Current Status</th>
                  <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">Stock Change</th>
                </tr>
              </thead>
              <tbody>
                {movements.map((movement, index) => (
                  <tr key={index} className="border-b border-slate-100 hover:bg-slate-50">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        {getMovementIcon(movement.movementType)}
                        {getMovementLabel(movement.movementType)}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-mono text-sm text-slate-800">{movement.sku}</span>
                    </td>
                    <td className="py-3 px-4 text-sm text-slate-600 truncate max-w-xs">
                      {movement.mainCategory}
                    </td>
                    <td className="py-3 px-4 text-center">
                      {getStatusBadge(movement.previousStatus)}
                    </td>
                    <td className="py-3 px-4 text-center">
                      {getStatusBadge(movement.currentStatus)}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-1">
                        {movement.previousStock !== movement.currentStock && (
                          <>
                            <span className="text-slate-500">{movement.previousStock}</span>
                            <ArrowUpRight className="w-3 h-3 text-slate-400" />
                            <span className={`font-medium ${
                              movement.currentStock > movement.previousStock 
                                ? 'text-emerald-600' 
                                : 'text-red-600'
                            }`}>
                              {movement.currentStock}
                            </span>
                          </>
                        )}
                        {movement.previousStock === movement.currentStock && (
                          <span className="text-slate-400">-</span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}