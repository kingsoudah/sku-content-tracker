import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { SummaryStats, CategoryStats } from '../types';

interface AnalyticsChartsProps {
  summary: SummaryStats;
  mainCategories: CategoryStats[];
}

export function AnalyticsCharts({ summary, mainCategories }: AnalyticsChartsProps) {
  const topCategories = mainCategories.slice(0, 6);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Publish Status */}
      <Card className="bg-white border border-slate-200 shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-800">Publish Status Distribution</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-slate-600">Published</span>
                <span className="font-medium text-slate-800">{summary.publishRate}%</span>
              </div>
              <div className="h-4 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 rounded-full transition-all"
                  style={{ width: `${summary.publishRate}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-slate-600">Draft</span>
                <span className="font-medium text-slate-800">{Math.round((summary.draftSKUs / summary.totalSKUs) * 100)}%</span>
              </div>
              <div className="h-4 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-amber-500 rounded-full transition-all"
                  style={{ width: `${(summary.draftSKUs / summary.totalSKUs) * 100}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-slate-600">Unpublished</span>
                <span className="font-medium text-slate-800">{Math.round((summary.unpublishedSKUs / summary.totalSKUs) * 100)}%</span>
              </div>
              <div className="h-4 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-red-500 rounded-full transition-all"
                  style={{ width: `${(summary.unpublishedSKUs / summary.totalSKUs) * 100}%` }}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* SLA Adherence */}
      <Card className="bg-white border border-slate-200 shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-800">Content Quality Metrics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-slate-600">SLA Adherence</span>
                <span className="font-medium text-slate-800">{summary.slaAdherenceRate}%</span>
              </div>
              <div className="h-4 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all ${
                    summary.slaAdherenceRate >= 80 ? 'bg-emerald-500' : 'bg-amber-500'
                  }`}
                  style={{ width: `${summary.slaAdherenceRate}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-slate-600">Image Coverage</span>
                <span className="font-medium text-slate-800">{summary.imageCompletionRate}%</span>
              </div>
              <div className="h-4 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-violet-500 rounded-full transition-all"
                  style={{ width: `${summary.imageCompletionRate}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-slate-600">Description Coverage</span>
                <span className="font-medium text-slate-800">{summary.descriptionRate}%</span>
              </div>
              <div className="h-4 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-pink-500 rounded-full transition-all"
                  style={{ width: `${summary.descriptionRate}%` }}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Category Performance */}
      <Card className="bg-white border border-slate-200 shadow-sm lg:col-span-2">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-800">Top Categories by SLA Adherence</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {topCategories.map((cat, index) => (
              <div key={index} className="flex items-center gap-4">
                <div className="w-32 text-sm text-slate-700 truncate">{cat.name}</div>
                <div className="flex-1">
                  <div className="h-6 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        cat.slaAdherence >= 80 ? 'bg-emerald-500' : 
                        cat.slaAdherence >= 60 ? 'bg-amber-500' : 'bg-red-500'
                      }`}
                      style={{ width: `${cat.slaAdherence}%` }}
                    />
                  </div>
                </div>
                <div className="w-16 text-right">
                  <span className={`text-sm font-medium ${
                    cat.slaAdherence >= 80 ? 'text-emerald-600' : 
                    cat.slaAdherence >= 60 ? 'text-amber-600' : 'text-red-600'
                  }`}>
                    {cat.slaAdherence}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}