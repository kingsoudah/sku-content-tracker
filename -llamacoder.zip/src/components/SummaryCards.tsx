import { Card, CardContent } from '../components/ui/card';
import { SummaryStats } from '../types';
import { Package, CheckCircle, AlertTriangle, TrendingUp, Image, FileText, Eye, XCircle, Lock } from 'lucide-react';

interface SummaryCardsProps {
  stats: SummaryStats;
}

export function SummaryCards({ stats }: SummaryCardsProps) {
  const cards = [
    {
      title: 'Total SKUs',
      value: stats.totalSKUs.toLocaleString(),
      description: 'Unique SKUs in the SKU column',
      icon: Package,
      bgColor: 'bg-blue-50',
      iconColor: 'text-blue-600',
      valueColor: 'text-blue-700'
    },
    {
      title: 'Published SKUs',
      value: stats.publishedSKUs.toLocaleString(),
      description: 'Status = "Publish"',
      icon: CheckCircle,
      bgColor: 'bg-emerald-50',
      iconColor: 'text-emerald-600',
      valueColor: 'text-emerald-700'
    },
    {
      title: 'Draft SKUs',
      value: stats.draftSKUs.toLocaleString(),
      description: 'Status = "Draft"',
      icon: AlertTriangle,
      bgColor: 'bg-amber-50',
      iconColor: 'text-amber-600',
      valueColor: 'text-amber-700'
    },
    {
      title: 'Private SKUs',
      value: stats.privateSKUs.toLocaleString(),
      description: 'Status = "Private"',
      icon: Lock,
      bgColor: 'bg-purple-50',
      iconColor: 'text-purple-600',
      valueColor: 'text-purple-700'
    },
    {
      title: 'Unpublished SKUs',
      value: stats.unpublishedSKUs.toLocaleString(),
      description: 'Stock < 4 AND (Draft/Private)',
      icon: XCircle,
      bgColor: 'bg-red-50',
      iconColor: 'text-red-600',
      valueColor: 'text-red-700'
    },
    {
      title: 'Sellable SKUs',
      value: stats.sellableSKUs.toLocaleString(),
      description: 'Stock > 4',
      icon: TrendingUp,
      bgColor: 'bg-cyan-50',
      iconColor: 'text-cyan-600',
      valueColor: 'text-cyan-700'
    },
    {
      title: 'SLA Adherence',
      value: `${stats.slaAdherenceRate}%`,
      description: '2+ images AND content ÷ Sellable',
      icon: CheckCircle,
      bgColor: stats.slaAdherenceRate >= 80 ? 'bg-emerald-50' : 'bg-amber-50',
      iconColor: stats.slaAdherenceRate >= 80 ? 'text-emerald-600' : 'text-amber-600',
      valueColor: stats.slaAdherenceRate >= 80 ? 'text-emerald-700' : 'text-amber-700',
      subtitle: `${stats.skusWithContentAndImages.toLocaleString()} of ${stats.sellableSKUs.toLocaleString()} sellable`
    },
    {
      title: 'Image Coverage',
      value: `${stats.imageCompletionRate}%`,
      description: 'Sellable SKUs with 2+ image URLs',
      icon: Image,
      bgColor: 'bg-indigo-50',
      iconColor: 'text-indigo-600',
      valueColor: 'text-indigo-700'
    }
  ];

  return (
    <div className="space-y-4">
      {/* Calculation Guide */}
      <div className="bg-slate-50 border border-slate-200 rounded-lg p-4">
        <h3 className="text-sm font-semibold text-slate-700 mb-3">📊 How Metrics Are Calculated</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          <div className="bg-white p-3 rounded border border-slate-200">
            <span className="font-semibold text-blue-700">Total SKUs</span>
            <p className="text-slate-600 mt-1">Count of unique values in the SKU column (duplicates removed)</p>
          </div>
          <div className="bg-white p-3 rounded border border-slate-200">
            <span className="font-semibold text-emerald-700">Published</span>
            <p className="text-slate-600 mt-1">All SKUs where Status = "Publish"</p>
          </div>
          <div className="bg-white p-3 rounded border border-slate-200">
            <span className="font-semibold text-red-700">Unpublished</span>
            <p className="text-slate-600 mt-1">SKUs with Stock &lt; 4 AND Status in (Draft, Private)</p>
          </div>
          <div className="bg-white p-3 rounded border border-slate-200">
            <span className="font-semibold text-cyan-700">Sellable</span>
            <p className="text-slate-600 mt-1">All SKUs where Stock &gt; 4</p>
          </div>
        </div>
        <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded">
          <p className="text-sm">
            <span className="font-semibold text-amber-800">SLA Adherence Formula:</span>{' '}
            <span className="text-amber-700">(SKUs with 2+ image URLs AND content) ÷ (Sellable SKUs) × 100</span>
          </p>
          <p className="text-xs text-amber-600 mt-1">
            ℹ️ Image URLs are counted by splitting the image column by comma. Content = non-empty description field.
          </p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {cards.map((card, index) => (
          <Card key={index} className={`${card.bgColor} border border-slate-200`}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <card.icon className={`w-5 h-5 ${card.iconColor}`} />
              </div>
              <p className={`text-2xl font-bold ${card.valueColor}`}>{card.value}</p>
              <p className="text-sm font-medium text-slate-700 mt-1">{card.title}</p>
              <p className="text-xs text-slate-500 mt-1">{card.description}</p>
              {card.subtitle && (
                <p className="text-xs text-slate-600 mt-2 font-medium">{card.subtitle}</p>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}