import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { CategoryStats } from '../types';
import { Sparkles } from 'lucide-react';

interface NewSKUsPanelProps {
  newSKUs: string[];
  newSKUBreakdown?: {
    mainCategories: CategoryStats[];
    subcategories: CategoryStats[];
  };
}

export function NewSKUsPanel({ newSKUs, newSKUBreakdown }: NewSKUsPanelProps) {
  const mainCategories = newSKUBreakdown?.mainCategories || [];
  const subcategories = newSKUBreakdown?.subcategories || [];

  if (newSKUs.length === 0) {
    return (
      <Card className="bg-white border border-slate-200 shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-800 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-violet-500" />
            New SKUs Detected
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-slate-500">
            No new SKUs detected in this upload. All SKUs match previous records.
          </div>
        </CardContent>
      </Card>
    );
  }

  const getStatusBadge = (value: number, total: number) => {
    const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
    return (
      <span className={`px-2 py-1 text-xs rounded-full ${
        percentage >= 80 ? 'bg-emerald-100 text-emerald-700' :
        percentage >= 50 ? 'bg-amber-100 text-amber-700' :
        'bg-red-100 text-red-700'
      }`}>
        {percentage}%
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Summary */}
      <Card className="bg-violet-50 border border-violet-200">
        <CardContent className="p-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-violet-100 rounded-full">
              <Sparkles className="w-6 h-6 text-violet-600" />
            </div>
            <div>
              <p className="text-3xl font-bold text-violet-700">{newSKUs.length}</p>
              <p className="text-sm text-violet-600">New SKUs detected in this upload</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* New SKUs by Main Category */}
      {mainCategories.length > 0 && (
        <Card className="bg-white border border-slate-200 shadow-sm">
          <CardHeader className="border-b border-slate-100">
            <CardTitle className="text-lg font-semibold text-slate-800">
              New SKUs by Main Category
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200">
                    <th className="text-left py-3 px-4 text-xs font-semibold text-slate-600">Category</th>
                    <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">Total New</th>
                    <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">Published</th>
                    <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">Draft</th>
                    <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">Unpublished</th>
                    <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">Sellable</th>
                    <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">SLA %</th>
                  </tr>
                </thead>
                <tbody>
                  {mainCategories.map((cat, index) => (
                    <tr key={index} className="border-b border-slate-100 hover:bg-slate-50">
                      <td className="py-3 px-4 text-sm text-slate-800 font-medium truncate max-w-xs">
                        {cat.name}
                      </td>
                      <td className="py-3 px-4 text-sm text-violet-600 font-bold text-center">{cat.total}</td>
                      <td className="py-3 px-4 text-sm text-emerald-600 text-center">{cat.published}</td>
                      <td className="py-3 px-4 text-sm text-amber-600 text-center">{cat.draft}</td>
                      <td className="py-3 px-4 text-sm text-red-600 text-center">{cat.unpublished}</td>
                      <td className="py-3 px-4 text-sm text-blue-600 text-center">{cat.sellable}</td>
                      <td className="py-3 px-4 text-center">
                        {getStatusBadge(cat.skusWithContentAndImages, cat.sellable)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* New SKUs by Subcategory */}
      {subcategories.length > 0 && (
        <Card className="bg-white border border-slate-200 shadow-sm">
          <CardHeader className="border-b border-slate-100">
            <CardTitle className="text-lg font-semibold text-slate-800">
              New SKUs by Subcategory
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200">
                    <th className="text-left py-3 px-4 text-xs font-semibold text-slate-600">Subcategory</th>
                    <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">Total New</th>
                    <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">Published</th>
                    <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">Draft</th>
                    <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">Unpublished</th>
                    <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">Sellable</th>
                    <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">SLA %</th>
                  </tr>
                </thead>
                <tbody>
                  {subcategories.slice(0, 15).map((cat, index) => (
                    <tr key={index} className="border-b border-slate-100 hover:bg-slate-50">
                      <td className="py-3 px-4 text-sm text-slate-800 font-medium truncate max-w-xs">
                        {cat.name}
                      </td>
                      <td className="py-3 px-4 text-sm text-violet-600 font-bold text-center">{cat.total}</td>
                      <td className="py-3 px-4 text-sm text-emerald-600 text-center">{cat.published}</td>
                      <td className="py-3 px-4 text-sm text-amber-600 text-center">{cat.draft}</td>
                      <td className="py-3 px-4 text-sm text-red-600 text-center">{cat.unpublished}</td>
                      <td className="py-3 px-4 text-sm text-blue-600 text-center">{cat.sellable}</td>
                      <td className="py-3 px-4 text-center">
                        {getStatusBadge(cat.skusWithContentAndImages, cat.sellable)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* SKU List */}
      <Card className="bg-white border border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-100">
          <CardTitle className="text-lg font-semibold text-slate-800">
            All New SKUs ({newSKUs.length})
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2">
            {newSKUs.map((sku, index) => (
              <div
                key={index}
                className="px-3 py-2 bg-violet-50 border border-violet-200 rounded-lg text-sm text-violet-800 font-mono truncate"
                title={sku}
              >
                {sku}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}