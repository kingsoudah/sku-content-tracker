import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Insight } from '../types';
import { INSIGHT_COLORS } from '../utils/constants';
import { AlertTriangle, XCircle, CheckCircle, Info } from 'lucide-react';

interface InsightsPanelProps {
  insights: Insight[];
}

export function InsightsPanel({ insights }: InsightsPanelProps) {
  const getIcon = (type: Insight['type']) => {
    switch (type) {
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-amber-500" />;
      case 'error':
        return <XCircle className="w-5 h-5 text-red-500" />;
      case 'success':
        return <CheckCircle className="w-5 h-5 text-emerald-500" />;
      default:
        return <Info className="w-5 h-5 text-blue-500" />;
    }
  };

  if (insights.length === 0) {
    return (
      <Card className="bg-white border border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-100">
          <CardTitle className="text-xl font-bold text-slate-900">Insights & Recommendations</CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="text-center py-8">
            <Info className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-500">Add data to see insights and recommendations</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white border border-slate-200 shadow-sm">
      <CardHeader className="border-b border-slate-100">
        <CardTitle className="text-xl font-bold text-slate-900">Insights & Recommendations</CardTitle>
        <p className="text-sm text-slate-500 mt-1">Actionable items to improve your content quality</p>
      </CardHeader>
      <CardContent className="p-4">
        <div className="space-y-3 max-h-96 overflow-y-auto">
          {insights.map((insight) => (
            <div
              key={insight.id}
              className={`p-4 rounded-lg border ${INSIGHT_COLORS[insight.type]}`}
            >
              <div className="flex items-start gap-3">
                <div className="flex-shrink-0 mt-0.5">
                  {getIcon(insight.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h4 className="font-semibold text-sm">{insight.title}</h4>
                    {insight.month && (
                      <span className="text-xs font-medium opacity-75">{insight.month}</span>
                    )}
                  </div>
                  <p className="mt-1 text-sm opacity-90">{insight.description}</p>
                  <p className="mt-2 text-xs font-medium opacity-75">{insight.impact}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}