import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { CategoryStats } from '../types';
import { Info } from 'lucide-react';

interface CategoryBreakdownTableProps {
  title: string;
  data: CategoryStats[];
}

export function CategoryBreakdownTable({ title, data }: CategoryBreakdownTableProps) {
  const getSLABadge = (sla: number) => {
    if (sla >= 80) {
      return <span className="px-2 py-1 text-xs rounded-full bg-emerald-100 text-emerald-700 font-medium">{sla}% ✓</span>;
    } else if (sla >= 50) {
      return <span className="px-2 py-1 text-xs rounded-full bg-amber-100 text-amber-700 font-medium">{sla}%</span>;
    } else {
      return <span className="px-2 py-1 text-xs rounded-full bg-red-100 text-red-700 font-medium">{sla}%</span>;
    }
  };

  return (
    <Card className="bg-white border border-slate-200 shadow-sm">
      <CardHeader className="border-b border-slate-100">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-slate-800">{title}</CardTitle>
          <span className="text-sm text-slate-500">{data.length} categories</span>
        </div>
        {/* Column Explanation */}
        <div className="mt-3 p-3 bg-slate-50 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Info className="w-4 h-4 text-slate-500" />
            <span className="text-xs font-semibold text-slate-700">Column Definitions</span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs text-slate-600">
            <div><span className="font-medium text-slate-800">Total:</span> Count of unique SKUs</div>
            <div><span className="font-medium text-slate-800">Published:</span> Status = "Publish"</div>
            <div><span className="font-medium text-slate-800">Unpublished:</span> Stock &lt;4 & (Draft/Private)</div>
            <div><span className="font-medium text-slate-800">Sellable:</span> Stock &gt;4</div>
            <div><span className="font-medium text-slate-800">2+ Images:</span> Sellable with 2+ URLs (comma-separated)</div>
            <div><span className="font-medium text-slate-800">Has Content:</span> Sellable with description</div>
            <div><span className="font-medium text-slate-800">SLA Met:</span> Sellable + 2+ images + content</div>
            <div><span className="font-medium text-slate-800">SLA %:</span> SLA Met ÷ Sellable × 100</div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="text-left py-3 px-4 text-xs font-semibold text-slate-600">Category</th>
                <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">Total</th>
                <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">Published</th>
                <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">Draft</th>
                <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">Private</th>
                <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">Unpublished</th>
                <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">Sellable</th>
                <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">2+ Images</th>
                <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">Content</th>
                <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">SLA Met</th>
                <th className="text-center py-3 px-4 text-xs font-semibold text-slate-600">SLA %</th>
              </tr>
            </thead>
            <tbody>
              {data.map((cat, index) => (
                <tr key={index} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="py-3 px-4 text-sm text-slate-800 font-medium truncate max-w-xs" title={cat.name}>
                    {cat.name || 'Uncategorized'}
                  </td>
                  <td className="py-3 px-4 text-sm text-slate-700 text-center font-medium">{cat.total.toLocaleString()}</td>
                  <td className="py-3 px-4 text-sm text-emerald-600 text-center">{cat.published.toLocaleString()}</td>
                  <td className="py-3 px-4 text-sm text-amber-600 text-center">{cat.draft.toLocaleString()}</td>
                  <td className="py-3 px-4 text-sm text-purple-600 text-center">{cat.private.toLocaleString()}</td>
                  <td className="py-3 px-4 text-sm text-red-600 text-center">{cat.unpublished.toLocaleString()}</td>
                  <td className="py-3 px-4 text-sm text-cyan-600 text-center font-medium">{cat.sellable.toLocaleString()}</td>
                  <td className="py-3 px-4 text-sm text-indigo-600 text-center">{cat.skusWith2Images.toLocaleString()}</td>
                  <td className="py-3 px-4 text-sm text-blue-600 text-center">{cat.skusWithContent.toLocaleString()}</td>
                  <td className="py-3 px-4 text-sm text-teal-600 text-center font-medium">{cat.skusWithContentAndImages.toLocaleString()}</td>
                  <td className="py-3 px-4 text-center">{getSLABadge(cat.slaAdherence)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}