import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { MONTHS, YEARS } from '../utils/constants';
import { SKUMonthlyData } from '../types';

interface DataInputFormProps {
  onSubmit: (data: Omit<SKUMonthlyData, 'id'>) => void;
  existingMonths: string[];
}

export function DataInputForm({ onSubmit, existingMonths }: DataInputFormProps) {
  const [month, setMonth] = useState('January');
  const [year, setYear] = useState(2024);
  const [totalSKUs, setTotalSKUs] = useState('');
  const [sellableSKUs, setSellableSKUs] = useState('');
  const [skusWith2Images, setSkusWith2Images] = useState('');
  const [skusWithDescription, setSkusWithDescription] = useState('');
  const [unpublishedSKUs, setUnpublishedSKUs] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const monthKey = `${month}-${year}`;
    if (existingMonths.includes(monthKey)) {
      alert('Data for this month already exists. Please select a different month or edit existing data.');
      return;
    }

    onSubmit({
      month,
      year,
      totalSKUs: parseInt(totalSKUs) || 0,
      sellableSKUs: parseInt(sellableSKUs) || 0,
      skusWith2Images: parseInt(skusWith2Images) || 0,
      skusWithDescription: parseInt(skusWithDescription) || 0,
      unpublishedSKUs: parseInt(unpublishedSKUs) || 0,
    });

    // Reset form
    setTotalSKUs('');
    setSellableSKUs('');
    setSkusWith2Images('');
    setSkusWithDescription('');
    setUnpublishedSKUs('');
  };

  return (
    <Card className="bg-white border border-slate-200 shadow-sm">
      <CardHeader className="border-b border-slate-100">
        <CardTitle className="text-xl font-bold text-slate-900">Add Monthly SKU Data</CardTitle>
        <CardDescription className="text-slate-500">
          Enter your monthly inventory and content metrics
        </CardDescription>
      </CardHeader>
      <CardContent className="p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="month" className="text-sm font-medium text-slate-700">Month</Label>
              <select
                id="month"
                value={month}
                onChange={(e) => setMonth(e.target.value)}
                className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {MONTHS.map((m) => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="year" className="text-sm font-medium text-slate-700">Year</Label>
              <select
                id="year"
                value={year}
                onChange={(e) => setYear(parseInt(e.target.value))}
                className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {YEARS.map((y) => (
                  <option key={y} value={y}>{y}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="totalSKUs" className="text-sm font-medium text-slate-700">Total SKUs</Label>
              <Input
                id="totalSKUs"
                type="number"
                placeholder="e.g., 1500"
                value={totalSKUs}
                onChange={(e) => setTotalSKUs(e.target.value)}
                className="border-slate-300 focus:ring-blue-500"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="sellableSKUs" className="text-sm font-medium text-slate-700">Sellable SKUs (Stock &gt; 4)</Label>
              <Input
                id="sellableSKUs"
                type="number"
                placeholder="e.g., 1200"
                value={sellableSKUs}
                onChange={(e) => setSellableSKUs(e.target.value)}
                className="border-slate-300 focus:ring-blue-500"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="skusWith2Images" className="text-sm font-medium text-slate-700">SKUs with 2+ Images</Label>
              <Input
                id="skusWith2Images"
                type="number"
                placeholder="e.g., 900"
                value={skusWith2Images}
                onChange={(e) => setSkusWith2Images(e.target.value)}
                className="border-slate-300 focus:ring-blue-500"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="skusWithDescription" className="text-sm font-medium text-slate-700">SKUs with Description</Label>
              <Input
                id="skusWithDescription"
                type="number"
                placeholder="e.g., 1000"
                value={skusWithDescription}
                onChange={(e) => setSkusWithDescription(e.target.value)}
                className="border-slate-300 focus:ring-blue-500"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="unpublishedSKUs" className="text-sm font-medium text-slate-700">Unpublished SKUs</Label>
            <Input
              id="unpublishedSKUs"
              type="number"
              placeholder="e.g., 50"
              value={unpublishedSKUs}
              onChange={(e) => setUnpublishedSKUs(e.target.value)}
              className="border-slate-300 focus:ring-blue-500"
              required
            />
          </div>

          <Button 
            type="submit" 
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2.5"
          >
            Add Monthly Data
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}