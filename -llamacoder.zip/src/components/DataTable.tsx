import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { SKUMonthlyData } from '../types';
import { calculateMetrics } from '../utils/calculations';
import { Trash2 } from 'lucide-react';

interface DataTableProps {
  data: SKUMonthlyData[];
  onDelete: (id: string) => void;
}

export function DataTable({ data, onDelete }: DataTableProps) {
  if (data.length === 0) {
    return null;
  }

  return (
    <Card className="bg-white border border-slate-200 shadow-sm">
      <CardHeader className="border-b border-slate-100">
        <CardTitle className="text-xl font-bold text-slate-900">Monthly Data Records</CardTitle>
        <p className="text-sm text-slate-500 mt-1">Click on a row to view detailed metrics</p>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wide">Month</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-slate-600 uppercase tracking-wide">Total SKUs</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-slate-600 uppercase tracking-wide">Sellable</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-slate-600 uppercase tracking-wide">2+ Images</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-slate-600 uppercase tracking-wide">Description</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-slate-600 uppercase tracking-wide">Unpublished</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-slate-600 uppercase tracking-wide">Quality %</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-600 uppercase tracking-wide">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {data.map((item) => {
                const metrics = calculateMetrics(item);
                return (
                  <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-4 py-3 text-sm font-medium text-slate-900">
                      {item.month} {item.year}
                    </td>
                    <td className="px-4 py-3 text-sm text-slate-700 text-right">
                      {item.totalSKUs.toLocaleString()}
                    </td>
                    <td className="px-4 py-3 text-sm text-slate-700 text-right">
                      {item.sellableSKUs.toLocaleString()}
                    </td>
                    <td className="px-4 py-3 text-sm text-right">
                      <span className="text-blue-600 font-medium">{item.skusWith2Images.toLocaleString()}</span>
                    </td>
                    <td className="px-4 py-3 text-sm text-right">
                      <span className="text-emerald-600 font-medium">{item.skusWithDescription.toLocaleString()}</span>
                    </td>
                    <td className="px-4 py-3 text-sm text-right">
                      <span className={`font-medium ${item.unpublishedSKUs > 0 ? 'text-red-600' : 'text-slate-500'}`}>
                        {item.unpublishedSKUs.toLocaleString()}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm text-right">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        metrics.contentQualityScore >= 80 ? 'bg-emerald-100 text-emerald-800' :
                        metrics.contentQualityScore >= 60 ? 'bg-amber-100 text-amber-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {metrics.contentQualityScore}%
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onDelete(item.id)}
                        className="text-slate-400 hover:text-red-500 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}