import { useCallback } from 'react';
import { Card, CardContent } from '../components/ui/card';
import { Upload, FileSpreadsheet, Loader2 } from 'lucide-react';

interface FileUploadZoneProps {
  onFileSelect: (file: File) => void;
  isProcessing: boolean;
}

export function FileUploadZone({ onFileSelect, isProcessing }: FileUploadZoneProps) {
  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file && file.name.endsWith('.csv')) {
      onFileSelect(file);
    }
  }, [onFileSelect]);

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onFileSelect(file);
    }
  };

  return (
    <Card className="bg-white border-2 border-dashed border-slate-300 hover:border-blue-400 transition-colors">
      <CardContent className="p-0">
        <label
          onDrop={handleDrop}
          onDragOver={(e) => e.preventDefault()}
          className="flex flex-col items-center justify-center py-16 px-4 cursor-pointer"
        >
          {isProcessing ? (
            <>
              <Loader2 className="w-16 h-16 text-blue-500 animate-spin mb-4" />
              <p className="text-lg font-medium text-slate-700">Processing CSV...</p>
              <p className="text-sm text-slate-500">Please wait</p>
            </>
          ) : (
            <>
              <div className="flex gap-4 mb-4">
                <Upload className="w-12 h-12 text-slate-400" />
                <FileSpreadsheet className="w-12 h-12 text-blue-500" />
              </div>
              <p className="text-lg font-medium text-slate-700 mb-2">
                Drag & drop your CSV file here
              </p>
              <p className="text-sm text-slate-500 mb-4">or</p>
              <span className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                Select CSV File
              </span>
              <p className="text-xs text-slate-400 mt-4">
                Supported format: .csv
              </p>
            </>
          )}
          <input
            type="file"
            accept=".csv"
            onChange={handleFileInput}
            className="hidden"
            disabled={isProcessing}
          />
        </label>
      </CardContent>
    </Card>
  );
}