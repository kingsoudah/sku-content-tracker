import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { SKUMonthlyData } from '../types';
import { calculateMetrics } from '../utils/calculations';

interface MetricsChartProps {
  data: SKUMonthlyData[];
}

export function MetricsChart({ data }: MetricsChartProps) {
  if (data.length === 0) {
    return (
      <Card className="bg-white border border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-100">
          <CardTitle className="text-xl font-bold text-slate-900">Content Quality Trends</CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="h-64 flex items-center justify-center text-slate-400">
            Add data to see trends
          </div>
        </CardContent>
      </Card>
    );
  }

  const sortedData = [...data].sort((a, b) => {
    const monthOrder = ['January', 'February', 'March', 'April', 'May', 'June', 
                        'July', 'August', 'September', 'October', 'November', 'December'];
    const aIndex = a.year * 12 + monthOrder.indexOf(a.month);
    const bIndex = b.year * 12 + monthOrder.indexOf(b.month);
    return aIndex - bIndex;
  });

  const metrics = sortedData.map(calculateMetrics);
  const maxValue = 100;

  return (
    <Card className="bg-white border border-slate-200 shadow-sm">
      <CardHeader className="border-b border-slate-100">
        <CardTitle className="text-xl font-bold text-slate-900">Content Quality Trends</CardTitle>
        <p className="text-sm text-slate-500 mt-1">Monthly performance overview</p>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-4">
          {sortedData.map((item, index) => {
            const m = metrics[index];
            return (
              <div key={item.id} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-slate-700">
                    {item.month.slice(0, 3)} {item.year}
                  </span>
                  <span className="text-sm text-slate-500">
                    {m.contentQualityScore}% quality score
                  </span>
                </div>
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 w-20">Images</span>
                    <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-blue-500 rounded-full transition-all duration-500"
                        style={{ width: `${Math.min(m.imageCompletionRate, maxValue)}%` }}
                      />
                    </div>
                    <span className="text-xs text-slate-600 w-12 text-right">{m.imageCompletionRate}%</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 w-20">Description</span>
                    <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-emerald-500 rounded-full transition-all duration-500"
                        style={{ width: `${Math.min(m.descriptionCompletionRate, maxValue)}%` }}
                      />
                    </div>
                    <span className="text-xs text-slate-600 w-12 text-right">{m.descriptionCompletionRate}%</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 w-20">Published</span>
                    <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-violet-500 rounded-full transition-all duration-500"
                        style={{ width: `${Math.min(m.publishRate, maxValue)}%` }}
                      />
                    </div>
                    <span className="text-xs text-slate-600 w-12 text-right">{m.publishRate}%</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        
        <div className="mt-6 pt-4 border-t border-slate-100">
          <div className="flex items-center justify-center gap-6 text-xs">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-blue-500 rounded-full" />
              <span className="text-slate-600">Image Completion</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-emerald-500 rounded-full" />
              <span className="text-slate-600">Description Rate</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-violet-500 rounded-full" />
              <span className="text-slate-600">Publish Rate</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}