import { useState } from 'react';
import { FileUploadZone } from './components/FileUploadZone';
import { SummaryCards } from './components/SummaryCards';
import { CategoryBreakdownTable } from './components/CategoryBreakdownTable';
import { IssueHighlights } from './components/IssueHighlights';
import { AnalyticsCharts } from './components/AnalyticsCharts';
import { NewSKUsPanel } from './components/NewSKUsPanel';
import { MovementTable } from './components/MovementTable';
import { ExportDropdown } from './components/ExportDropdown';
import { parseCSVFile } from './utils/csvParser';
import { analyzeData, clearHistory } from './utils/dataAnalyzer';
import { AnalyticsData, SKUData } from './types';
import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card';
import { Button } from './components/ui/button';
import { FileSpreadsheet, ArrowLeft, Trash2, History } from 'lucide-react';

function App() {
  const [isProcessing, setIsProcessing] = useState(false);
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData | null>(null);
  const [rawData, setRawData] = useState<SKUData[]>([]);
  const [fileName, setFileName] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'overview' | 'sla' | 'categories' | 'newskus' | 'movement' | 'issues'>('overview');

  const handleFileSelect = async (file: File) => {
    setIsProcessing(true);
    setFileName(file.name);
    
    try {
      const data = await parseCSVFile(file);
      setRawData(data);
      const analytics = analyzeData(data);
      setAnalyticsData(analytics);
    } catch (error) {
      console.error('Error processing file:', error);
      alert('Error processing file. Please check the CSV format.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleClearHistory = () => {
    if (confirm('Are you sure you want to clear all tracking history? This cannot be undone.')) {
      clearHistory();
      alert('History cleared successfully.');
    }
  };

  const handleReset = () => {
    setAnalyticsData(null);
    setRawData([]);
    setFileName('');
    setActiveTab('overview');
  };

  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'sla', label: 'SLA' },
    { id: 'categories', label: 'Categories' },
    { id: 'newskus', label: 'New SKUs' },
    { id: 'movement', label: 'Movement' },
    { id: 'issues', label: 'Issues' }
  ] as const;

  if (!analyticsData) {
    return (
      <div className="min-h-screen bg-slate-50">
        <header className="bg-white border-b border-slate-200">
          <div className="max-w-7xl mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <FileSpreadsheet className="w-8 h-8 text-blue-600" />
                <div>
                  <h1 className="text-xl font-bold text-slate-900">SKU Content Tracker</h1>
                  <p className="text-sm text-slate-500">Monitor SKU content quality and track changes</p>
                </div>
              </div>
              <Button
                variant="outline"
                onClick={handleClearHistory}
                className="text-red-600 border-red-200 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Clear History
              </Button>
            </div>
          </div>
        </header>
        
        <main className="max-w-4xl mx-auto px-4 py-12">
          <FileUploadZone onFileSelect={handleFileSelect} isProcessing={isProcessing} />
          
          <div className="mt-8 p-6 bg-white rounded-lg border border-slate-200">
            <h2 className="text-lg font-semibold text-slate-800 mb-4">Expected CSV Format</h2>
            <div className="text-sm text-slate-600 space-y-2">
              <p>Your CSV should contain the following columns:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li><strong>SKU</strong> - Unique product identifier</li>
                <li><strong>Title</strong> - Product title</li>
                <li><strong>Content</strong> - Product description</li>
                <li><strong>ImageUrl</strong> - Image URLs (comma-separated for multiple)</li>
                <li><strong>Status</strong> - Published, Draft, or Private</li>
                <li><strong>Stock</strong> - Stock quantity</li>
                <li><strong>Main Category</strong> - Primary category</li>
                <li><strong>Subcategory</strong> - Secondary category</li>
              </ul>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" onClick={handleReset} className="mr-2">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
              <FileSpreadsheet className="w-8 h-8 text-blue-600" />
              <div>
                <h1 className="text-xl font-bold text-slate-900">SKU Content Tracker</h1>
                <p className="text-sm text-slate-500">{fileName} • {analyticsData.summary.totalSKUs.toLocaleString()} SKUs</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <ExportDropdown 
                analyticsData={analyticsData} 
                rawData={rawData} 
                fileName={fileName} 
              />
            </div>
          </div>
        </div>
      </header>

      <div className="border-b border-slate-200 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <nav className="flex gap-1 overflow-x-auto">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 py-6">
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <SummaryCards stats={analyticsData.summary} />
            <AnalyticsCharts 
              summary={analyticsData.summary} 
              mainCategories={analyticsData.categoryBreakdown.mainCategories} 
            />
            <IssueHighlights issues={analyticsData.issues} />
          </div>
        )}

        {activeTab === 'sla' && (
          <div className="space-y-6">
            <Card className="bg-white border border-slate-200 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-slate-800">SLA Adherence Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center p-6 bg-slate-50 rounded-lg">
                    <p className="text-4xl font-bold text-blue-600">{analyticsData.summary.slaAdherenceRate}%</p>
                    <p className="text-sm text-slate-600 mt-2">Current SLA Adherence</p>
                    <p className="text-xs text-slate-500 mt-1">Target: 80%</p>
                  </div>
                  <div className="text-center p-6 bg-emerald-50 rounded-lg">
                    <p className="text-4xl font-bold text-emerald-600">{analyticsData.summary.skusWithContentAndImages}</p>
                    <p className="text-sm text-slate-600 mt-2">SKUs Meeting SLA</p>
                    <p className="text-xs text-slate-500 mt-1">2+ images + description</p>
                  </div>
                  <div className="text-center p-6 bg-amber-50 rounded-lg">
                    <p className="text-4xl font-bold text-amber-600">{analyticsData.summary.sellableSKUs - analyticsData.summary.skusWithContentAndImages}</p>
                    <p className="text-sm text-slate-600 mt-2">SKUs Needing Attention</p>
                    <p className="text-xs text-slate-500 mt-1">Missing images or description</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <CategoryBreakdownTable 
              title="SLA by Main Category" 
              data={analyticsData.categoryBreakdown.mainCategories} 
            />
          </div>
        )}

        {activeTab === 'categories' && (
          <div className="space-y-6">
            <CategoryBreakdownTable 
              title="Main Categories" 
              data={analyticsData.categoryBreakdown.mainCategories} 
            />
            <CategoryBreakdownTable 
              title="Subcategories" 
              data={analyticsData.categoryBreakdown.subcategories.slice(0, 20)} 
            />
          </div>
        )}

        {activeTab === 'newskus' && (
          <NewSKUsPanel 
            newSKUs={analyticsData.newSKUs} 
            newSKUBreakdown={analyticsData.newSKUBreakdown}
          />
        )}

        {activeTab === 'movement' && (
          <MovementTable movements={analyticsData.movements} />
        )}

        {activeTab === 'issues' && (
          <div className="space-y-6">
            <IssueHighlights issues={analyticsData.issues} />
            
            {analyticsData.summary.unpublishedSKUs > 0 && (
              <Card className="bg-white border border-slate-200 shadow-sm">
                <CardHeader>
                  <CardTitle className="text-lg font-semibold text-slate-800">
                    Unpublished SKUs Impact Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <p className="text-slate-600">
                      {analyticsData.summary.unpublishedSKUs} SKUs are currently unpublished due to low stock (&lt; 4) 
                      and Draft/Private status. These items are not visible to customers.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 bg-red-50 rounded-lg border border-red-200">
                        <p className="text-2xl font-bold text-red-700">{analyticsData.summary.unpublishedSKUs}</p>
                        <p className="text-sm text-red-600">SKUs losing potential sales</p>
                      </div>
                      <div className="p-4 bg-amber-50 rounded-lg border border-amber-200">
                        <p className="text-2xl font-bold text-amber-700">{analyticsData.summary.draftSKUs}</p>
                        <p className="text-sm text-amber-600">SKUs in Draft status</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </main>
    </div>
  );
}

export default App;