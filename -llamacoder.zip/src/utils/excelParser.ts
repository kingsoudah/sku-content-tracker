import { SKUData } from '../types';

export async function parseExcelFile(file: File): Promise<{ data: SKUData[], sheetNames: string[] }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetNames = workbook.SheetNames;
        
        const allData: SKUData[] = [];
        
        sheetNames.forEach((sheetName) => {
          const worksheet = workbook.Sheets[sheetName];
          const jsonData = XLSX.utils.sheet_to_json(worksheet);
          
          jsonData.forEach((row: any) => {
            const sku: SKUData = {
              sku: row['SKU'] || row['sku'] || row['Sku'] || '',
              category: row['Category'] || row['category'] || row['Main Category'] || '',
              subcategory: row['Subcategory'] || row['subcategory'] || row['Sub Category'] || '',
              subSubcategory: row['Sub-subcategory'] || row['SubSubcategory'] || row['Sub-Sub Category'] || '',
              status: normalizeStatus(row['Status'] || row['status'] || 'Draft'),
              stock: parseInt(row['Stock'] || row['stock'] || row['Quantity'] || '0'),
              hasImages: (row['Has Images'] || row['has_images'] || '').toString().toLowerCase() === 'yes' || 
                         parseInt(row['Image Count'] || row['image_count'] || '0') > 0,
              imageCount: parseInt(row['Image Count'] || row['image_count'] || row['Images'] || '0'),
              hasDescription: (row['Has Description'] || row['has_description'] || '').toString().toLowerCase() === 'yes' ||
                              parseInt(row['Description Length'] || row['description_length'] || '0') > 0,
              descriptionLength: parseInt(row['Description Length'] || row['description_length'] || '0'),
              createdAt: row['Created At'] || row['created_at'] || new Date().toISOString(),
              updatedAt: row['Updated At'] || row['updated_at'] || new Date().toISOString(),
            };
            
            if (sku.sku) {
              allData.push(sku);
            }
          });
        });
        
        resolve({ data: allData, sheetNames });
      } catch (error) {
        reject(new Error('Failed to parse Excel file. Please check the file format.'));
      }
    };
    
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsArrayBuffer(file);
  });
}

function normalizeStatus(status: string): 'Draft' | 'Published' | 'Unpublished' {
  const normalized = status.toLowerCase().trim();
  if (normalized === 'published' || normalized === 'live' || normalized === 'active') return 'Published';
  if (normalized === 'draft' || normalized === 'pending') return 'Draft';
  return 'Unpublished';
}

// Mock XLSX for demo - in production, use actual xlsx library
const XLSX = {
  read: (data: any, options: any) => ({
    SheetNames: ['Sheet1'],
    Sheets: {
      Sheet1: {}
    }
  }),
  utils: {
    sheet_to_json: (sheet: any) => []
  }
};