import { SKUData } from '../types';

export async function parseCSVFile(file: File): Promise<SKUData[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const data = parseCSV(text);
        resolve(data);
      } catch (error) {
        reject(error);
      }
    };
    
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsText(file);
  });
}

function parseCSV(text: string): SKUData[] {
  const lines = text.split(/\r?\n/).filter(line => line.trim());
  
  if (lines.length < 2) {
    throw new Error('CSV file is empty or has no data rows');
  }
  
  const headers = parseCSVLine(lines[0]).map(h => h.toLowerCase().trim());
  
  const skuIndex = headers.findIndex(h => h === 'sku');
  const titleIndex = headers.findIndex(h => h === 'title');
  const contentIndex = headers.findIndex(h => h === 'content' || h === 'description');
  const imageUrlIndex = headers.findIndex(h => h.includes('image'));
  const statusIndex = headers.findIndex(h => h === 'status');
  const stockIndex = headers.findIndex(h => h === 'stock');
  const mainCatIndex = headers.findIndex(h => h.includes('main category') || h === 'main category' || h === 'main_category');
  const subcatIndex = headers.findIndex(h => h === 'subcategory' || h === 'sub_category');
  const subSubcatIndex = headers.findIndex(h => h.includes('sub-sub-category') || h === 'sub_subcategory');
  
  const results: SKUData[] = [];
  
  for (let i = 1; i < lines.length; i++) {
    const values = parseCSVLine(lines[i]);
    
    if (values.length < 3) continue;
    
    const sku = getValue(values, skuIndex, '');
    if (!sku.trim()) continue;
    
    const title = getValue(values, titleIndex, '');
    const content = getValue(values, contentIndex, '');
    const imageUrl = getValue(values, imageUrlIndex, '');
    const statusRaw = getValue(values, statusIndex, '').trim();
    const stock = parseInt(getValue(values, stockIndex, '0')) || 0;
    const mainCategory = getValue(values, mainCatIndex, 'Uncategorized');
    const subcategory = getValue(values, subcatIndex, 'Uncategorized');
    const subSubcategory = getValue(values, subSubcatIndex, 'Uncategorized');
    
    // Count image URLs (comma-separated)
    const imageCount = imageUrl.split(',').filter(url => url.trim()).length;
    const has2Images = imageCount >= 2;
    const hasContent = content.trim().length > 0;
    const isSellable = stock > 4;
    
    // Status normalization - keep original value for "Publish" check
    let status = statusRaw;
    // Only normalize if not "Publish"
    if (statusRaw.toLowerCase() !== 'publish') {
      if (statusRaw.toLowerCase() === 'published') {
        status = 'Publish'; // Also accept "Published" as "Publish"
      } else if (statusRaw.toLowerCase() === 'draft') {
        status = 'Draft';
      } else if (statusRaw.toLowerCase() === 'private') {
        status = 'Private';
      }
    }
    
    results.push({
      sku,
      title,
      content,
      imageUrls: imageUrl,
      productCategories: '',
      status,
      stock,
      mainCategory,
      subcategory,
      subSubcategory,
      subSubSubcategory: '',
      has2Images,
      hasContent,
      isSellable
    });
  }
  
  return results;
}

function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    
    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  
  result.push(current.trim());
  return result;
}

function getValue(values: string[], index: number, defaultValue: string): string {
  if (index === -1 || index >= values.length) return defaultValue;
  return values[index] || defaultValue;
}