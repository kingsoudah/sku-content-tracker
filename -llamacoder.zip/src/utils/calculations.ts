import { SKUMonthlyData, ContentMetrics, DashboardStats, Insight } from '../types';

export function calculateMetrics(data: SKUMonthlyData): ContentMetrics {
  const imageCompletionRate = data.sellableSKUs > 0 
    ? (data.skusWith2Images / data.sellableSKUs) * 100 
    : 0;
  
  const descriptionCompletionRate = data.sellableSKUs > 0 
    ? (data.skusWithDescription / data.sellableSKUs) * 100 
    : 0;
  
  const contentQualityScore = (imageCompletionRate + descriptionCompletionRate) / 2;
  
  const sellableRate = data.totalSKUs > 0 
    ? (data.sellableSKUs / data.totalSKUs) * 100 
    : 0;
  
  const publishRate = data.totalSKUs > 0 
    ? ((data.totalSKUs - data.unpublishedSKUs) / data.totalSKUs) * 100 
    : 0;

  return {
    month: data.month,
    year: data.year,
    imageCompletionRate: Math.round(imageCompletionRate * 10) / 10,
    descriptionCompletionRate: Math.round(descriptionCompletionRate * 10) / 10,
    contentQualityScore: Math.round(contentQualityScore * 10) / 10,
    sellableRate: Math.round(sellableRate * 10) / 10,
    publishRate: Math.round(publishRate * 10) / 10,
  };
}

export function calculateDashboardStats(allData: SKUMonthlyData[]): DashboardStats {
  const totalSKUsAllTime = allData.reduce((sum, d) => sum + d.totalSKUs, 0);
  const totalSellable = allData.reduce((sum, d) => sum + d.sellableSKUs, 0);
  const totalUnpublished = allData.reduce((sum, d) => sum + d.unpublishedSKUs, 0);
  
  const metrics = allData.map(calculateMetrics);
  const avgContentQuality = metrics.length > 0 
    ? metrics.reduce((sum, m) => sum + m.contentQualityScore, 0) / metrics.length 
    : 0;
  
  const avgSellableRate = metrics.length > 0 
    ? metrics.reduce((sum, m) => sum + m.sellableRate, 0) / metrics.length 
    : 0;

  return {
    totalSKUsAllTime,
    avgContentQuality: Math.round(avgContentQuality * 10) / 10,
    avgSellableRate: Math.round(avgSellableRate * 10) / 10,
    totalUnpublished,
    potentialRevenueLoss: totalUnpublished * 15.50,
  };
}

export function generateInsights(allData: SKUMonthlyData[]): Insight[] {
  const insights: Insight[] = [];
  
  allData.forEach(data => {
    const metrics = calculateMetrics(data);
    
    // Unpublished SKUs insight
    if (data.unpublishedSKUs > 0) {
      const potentialLoss = data.unpublishedSKUs * 15.50;
      insights.push({
        id: `unpublished-${data.id}`,
        type: 'error',
        title: 'Unpublished SKUs Detected',
        description: `${data.unpublishedSKUs} SKUs remain unpublished in ${data.month} ${data.year}`,
        impact: `Estimated revenue impact: $${potentialLoss.toFixed(2)}`,
        month: `${data.month} ${data.year}`,
      });
    }
    
    // Low image completion
    if (metrics.imageCompletionRate < 70) {
      insights.push({
        id: `images-${data.id}`,
        type: 'warning',
        title: 'Low Image Coverage',
        description: `Only ${metrics.imageCompletionRate}% of sellable SKUs have 2+ images in ${data.month} ${data.year}`,
        impact: 'May affect conversion rates and customer engagement',
        month: `${data.month} ${data.year}`,
      });
    }
    
    // Low description rate
    if (metrics.descriptionCompletionRate < 80) {
      insights.push({
        id: `desc-${data.id}`,
        type: 'warning',
        title: 'Description Gap',
        description: `${metrics.descriptionCompletionRate}% description completion in ${data.month} ${data.year}`,
        impact: 'Missing descriptions can hurt SEO and customer trust',
        month: `${data.month} ${data.year}`,
      });
    }
    
    // Success insight
    if (metrics.contentQualityScore >= 85) {
      insights.push({
        id: `success-${data.id}`,
        type: 'success',
        title: 'Excellent Content Quality',
        description: `${data.month} ${data.year} achieved ${metrics.contentQualityScore}% content quality score`,
        impact: 'High quality content drives better sales performance',
        month: `${data.month} ${data.year}`,
      });
    }
  });
  
  return insights.sort((a, b) => {
    const order = { error: 0, warning: 1, info: 2, success: 3 };
    return order[a.type] - order[b.type];
  });
}

export function generateId(): string {
  return `sku-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}