import { AnalyticsData, SKUData } from '../types';

export function exportAnalyticsToCSV(data: AnalyticsData, fileName: string): void {
  const rows: string[][] = [];
  
  // Header
  rows.push(['SKU Content Analytics Report']);
  rows.push(['Generated:', new Date().toLocaleString()]);
  rows.push([]);
  
  // Summary Statistics
  rows.push(['=== SUMMARY STATISTICS ===']);
  rows.push(['Metric', 'Value']);
  rows.push(['Total SKUs', data.summary.totalSKUs.toString()]);
  rows.push(['Published SKUs', data.summary.publishedSKUs.toString()]);
  rows.push(['Draft SKUs', data.summary.draftSKUs.toString()]);
  rows.push(['Unpublished SKUs', data.summary.unpublishedSKUs.toString()]);
  rows.push(['Sellable SKUs (Stock > 4)', data.summary.sellableSKUs.toString()]);
  rows.push(['Published & Sellable', data.summary.publishedAndSellable.toString()]);
  rows.push(['SKUs with 2+ Images', data.summary.skusWith2Images.toString()]);
  rows.push(['SKUs with Description', data.summary.skusWithDescription.toString()]);
  rows.push(['SKUs with Content & Images (SLA)', data.summary.skusWithContentAndImages.toString()]);
  rows.push(['New SKUs This Upload', data.summary.newSKUsThisUpload.toString()]);
  rows.push(['Average Stock', data.summary.avgStock.toString()]);
  rows.push([]);
  
  // Rates
  rows.push(['=== RATES & PERCENTAGES ===']);
  rows.push(['Metric', 'Value']);
  rows.push(['Image Completion Rate', `${data.summary.imageCompletionRate}%`]);
  rows.push(['Description Rate', `${data.summary.descriptionRate}%`]);
  rows.push(['SLA Adherence Rate', `${data.summary.slaAdherenceRate}%`]);
  rows.push(['Publish Rate', `${data.summary.publishRate}%`]);
  rows.push([]);
  
  // Category Breakdown
  rows.push(['=== MAIN CATEGORIES ===']);
  rows.push(['Category', 'Total', 'Published', 'Draft', 'Unpublished', 'Sellable', 'Pub+Sellable', 'SLA Adherence %']);
  data.categoryBreakdown.mainCategories.forEach(cat => {
    rows.push([
      cat.name,
      cat.total.toString(),
      cat.published.toString(),
      cat.draft.toString(),
      cat.unpublished.toString(),
      cat.sellable.toString(),
      cat.publishedAndSellable.toString(),
      `${cat.slaAdherence}%`
    ]);
  });
  rows.push([]);
  
  // Subcategories
  rows.push(['=== SUBCATEGORIES ===']);
  rows.push(['Subcategory', 'Total', 'Published', 'Draft', 'Unpublished', 'Sellable', 'Pub+Sellable', 'SLA Adherence %']);
  data.categoryBreakdown.subcategories.slice(0, 20).forEach(cat => {
    rows.push([
      cat.name,
      cat.total.toString(),
      cat.published.toString(),
      cat.draft.toString(),
      cat.unpublished.toString(),
      cat.sellable.toString(),
      cat.publishedAndSellable.toString(),
      `${cat.slaAdherence}%`
    ]);
  });
  rows.push([]);
  
  // New SKUs
  rows.push(['=== NEW SKUs DETECTED ===']);
  rows.push(['SKU']);
  data.newSKUs.forEach(sku => {
    rows.push([sku]);
  });
  rows.push([]);
  
  // Issues
  rows.push(['=== INSIGHTS & ISSUES ===']);
  rows.push(['Type', 'Title', 'Description', 'Count', 'Impact']);
  data.issues.forEach(issue => {
    rows.push([
      issue.type.toUpperCase(),
      issue.title,
      issue.description,
      issue.count.toString(),
      issue.impact || ''
    ]);
  });
  
  // Create and download
  const csvContent = rows.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(',')).join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `${fileName}-analytics.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
}

export function exportSummaryReport(data: AnalyticsData, fileName: string): void {
  const rows: string[][] = [];
  
  // Executive Summary
  rows.push(['EXECUTIVE SUMMARY REPORT']);
  rows.push(['Report Date:', new Date().toLocaleDateString()]);
  rows.push(['Report Time:', new Date().toLocaleTimeString()]);
  rows.push([]);
  
  // Key Metrics
  rows.push(['KEY METRICS']);
  rows.push(['Metric', 'Current Value', 'Target', 'Status']);
  
  const slaStatus = data.summary.slaAdherenceRate >= 80 ? '✓ Good' : data.summary.slaAdherenceRate >= 60 ? '⚠ Needs Improvement' : '✗ Critical';
  const publishStatus = data.summary.publishRate >= 90 ? '✓ Good' : data.summary.publishRate >= 70 ? '⚠ Needs Improvement' : '✗ Critical';
  const imageStatus = data.summary.imageCompletionRate >= 80 ? '✓ Good' : data.summary.imageCompletionRate >= 60 ? '⚠ Needs Improvement' : '✗ Critical';
  
  rows.push(['SLA Adherence', `${data.summary.slaAdherenceRate}%`, '80%', slaStatus]);
  rows.push(['Publish Rate', `${data.summary.publishRate}%`, '90%', publishStatus]);
  rows.push(['Image Coverage', `${data.summary.imageCompletionRate}%`, '80%', imageStatus]);
  rows.push(['Description Coverage', `${data.summary.descriptionRate}%`, '90%', data.summary.descriptionRate >= 90 ? '✓ Good' : '⚠ Needs Improvement']);
  rows.push([]);
  
  // Inventory Overview
  rows.push(['INVENTORY OVERVIEW']);
  rows.push(['Category', 'Count', 'Percentage']);
  rows.push(['Total SKUs', data.summary.totalSKUs.toString(), '100%']);
  rows.push(['Published', data.summary.publishedSKUs.toString(), `${data.summary.publishRate}%`]);
  rows.push(['Draft', data.summary.draftSKUs.toString(), `${Math.round((data.summary.draftSKUs / data.summary.totalSKUs) * 100)}%`]);
  rows.push(['Unpublished', data.summary.unpublishedSKUs.toString(), `${Math.round((data.summary.unpublishedSKUs / data.summary.totalSKUs) * 100)}%`]);
  rows.push(['Sellable (Stock > 4)', data.summary.sellableSKUs.toString(), `${Math.round((data.summary.sellableSKUs / data.summary.totalSKUs) * 100)}%`]);
  rows.push([]);
  
  // New SKUs
  rows.push(['NEW SKUs THIS UPLOAD']);
  rows.push(['Count', data.summary.newSKUsThisUpload.toString()]);
  rows.push([]);
  
  // Action Items
  rows.push(['RECOMMENDED ACTIONS']);
  data.issues.filter(i => i.type === 'error' || i.type === 'warning').forEach((issue, idx) => {
    rows.push([`${idx + 1}. ${issue.title}`, issue.description, issue.impact || '']);
  });
  
  const csvContent = rows.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(',')).join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `${fileName}-summary-report.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
}

export function exportNewSKUsList(data: AnalyticsData, fileName: string): void {
  const rows: string[][] = [];
  
  rows.push(['New SKUs Detected']);
  rows.push(['Upload Date:', new Date().toLocaleString()]);
  rows.push(['Total New SKUs:', data.newSKUs.length.toString()]);
  rows.push([]);
  rows.push(['SKU']);
  
  data.newSKUs.forEach(sku => {
    rows.push([sku]);
  });
  
  const csvContent = rows.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(',')).join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `${fileName}-new-skus.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
}

export function exportCategoryBreakdown(data: AnalyticsData, fileName: string): void {
  const rows: string[][] = [];
  
  rows.push(['Category Breakdown Report']);
  rows.push(['Generated:', new Date().toLocaleString()]);
  rows.push([]);
  
  // Main Categories
  rows.push(['MAIN CATEGORIES']);
  rows.push(['Category', 'Total SKUs', 'Published', 'Draft', 'Unpublished', 'Sellable', 'Published & Sellable', 'With 2+ Images', 'With Description', 'SLA Compliant', 'SLA %']);
  
  data.categoryBreakdown.mainCategories.forEach(cat => {
    rows.push([
      cat.name,
      cat.total.toString(),
      cat.published.toString(),
      cat.draft.toString(),
      cat.unpublished.toString(),
      cat.sellable.toString(),
      cat.publishedAndSellable.toString(),
      cat.skusWith2Images.toString(),
      cat.skusWithDescription.toString(),
      cat.skusWithContentAndImages.toString(),
      `${cat.slaAdherence}%`
    ]);
  });
  rows.push([]);
  
  // Subcategories
  rows.push(['SUBCATEGORIES']);
  rows.push(['Subcategory', 'Total SKUs', 'Published', 'Draft', 'Unpublished', 'Sellable', 'Published & Sellable', 'With 2+ Images', 'With Description', 'SLA Compliant', 'SLA %']);
  
  data.categoryBreakdown.subcategories.forEach(cat => {
    rows.push([
      cat.name,
      cat.total.toString(),
      cat.published.toString(),
      cat.draft.toString(),
      cat.unpublished.toString(),
      cat.sellable.toString(),
      cat.publishedAndSellable.toString(),
      cat.skusWith2Images.toString(),
      cat.skusWithDescription.toString(),
      cat.skusWithContentAndImages.toString(),
      `${cat.slaAdherence}%`
    ]);
  });
  rows.push([]);
  
  // Sub-subcategories
  rows.push(['SUB-SUBCATEGORIES']);
  rows.push(['Sub-subcategory', 'Total SKUs', 'Published', 'Draft', 'Unpublished', 'Sellable', 'Published & Sellable', 'With 2+ Images', 'With Description', 'SLA Compliant', 'SLA %']);
  
  data.categoryBreakdown.subSubcategories.forEach(cat => {
    rows.push([
      cat.name,
      cat.total.toString(),
      cat.published.toString(),
      cat.draft.toString(),
      cat.unpublished.toString(),
      cat.sellable.toString(),
      cat.publishedAndSellable.toString(),
      cat.skusWith2Images.toString(),
      cat.skusWithDescription.toString(),
      cat.skusWithContentAndImages.toString(),
      `${cat.slaAdherence}%`
    ]);
  });
  
  const csvContent = rows.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(',')).join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `${fileName}-category-breakdown.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
}

export function exportUnpublishedSKUs(rawData: SKUData[], fileName: string): void {
  const rows: string[][] = [];
  
  rows.push(['Unpublished SKUs Report']);
  rows.push(['Generated:', new Date().toLocaleString()]);
  rows.push([]);
  rows.push(['SKU', 'Title', 'Status', 'Stock', 'Main Category', 'Subcategory', 'Has 2+ Images', 'Has Description', 'Is Sellable']);
  
  const unpublished = rawData.filter(s => s.status === 'Unpublished' || s.status === 'Draft');
  
  unpublished.forEach(sku => {
    rows.push([
      sku.sku,
      sku.title,
      sku.status,
      sku.stock.toString(),
      sku.mainCategory,
      sku.subcategory,
      sku.has2Images ? 'Yes' : 'No',
      sku.hasDescription ? 'Yes' : 'No',
      sku.isSellable ? 'Yes' : 'No'
    ]);
  });
  
  const csvContent = rows.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(',')).join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `${fileName}-unpublished-skus.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
}

export function exportSLAReport(data: AnalyticsData, fileName: string): void {
  const rows: string[][] = [];
  
  rows.push(['SLA Adherence Report']);
  rows.push(['Generated:', new Date().toLocaleString()]);
  rows.push([]);
  rows.push(['Overall SLA Adherence:', `${data.summary.slaAdherenceRate}%`]);
  rows.push(['Sellable SKUs:', data.summary.sellableSKUs.toString()]);
  rows.push(['SLA Compliant (2+ Images + Description):', data.summary.skusWithContentAndImages.toString()]);
  rows.push([]);
  
  rows.push(['CATEGORY SLA BREAKDOWN']);
  rows.push(['Category', 'Sellable SKUs', 'SLA Compliant', 'SLA %', 'Status']);
  
  data.categoryBreakdown.mainCategories.forEach(cat => {
    const status = cat.slaAdherence >= 80 ? '✓ Meeting SLA' : cat.slaAdherence >= 60 ? '⚠ Below Target' : '✗ Critical';
    rows.push([
      cat.name,
      cat.sellable.toString(),
      cat.skusWithContentAndImages.toString(),
      `${cat.slaAdherence}%`,
      status
    ]);
  });
  
  const csvContent = rows.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(',')).join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `${fileName}-sla-report.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
}