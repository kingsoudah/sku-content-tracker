import { SKUData, AnalyticsData, CategoryStats, Issue, UploadRecord, SummaryStats, SKUMovement, SKURecord } from '../types';
import { STORAGE_KEYS } from './constants';

/**
 * Parse image URLs from a comma-separated string
 * Returns count of valid URLs
 */
function countImageUrls(urlString: string): number {
  if (!urlString || urlString.trim() === '') return 0;
  
  // Split by comma and filter out empty strings
  const urls = urlString
    .split(',')
    .map(url => url.trim())
    .filter(url => url.length > 0);
  
  return urls.length;
}

/**
 * Check if content/description exists
 */
function hasContent(content: string): boolean {
  return content && content.trim().length > 0;
}

/**
 * Parse CSV row handling quoted fields
 */
function parseCSVRow(row: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;
  
  for (let i = 0; i < row.length; i++) {
    const char = row[i];
    
    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current.trim());
  
  return result;
}

/**
 * Parse CSV file and extract SKU data
 */
export function parseCSV(csvText: string): SKUData[] {
  const lines = csvText.split(/\r?\n/).filter(line => line.trim());
  
  if (lines.length < 2) {
    throw new Error('CSV file must have at least a header row and one data row');
  }
  
  // Parse header
  const headers = parseCSVRow(lines[0]).map(h => h.toLowerCase().trim().replace(/['"]/g, ''));
  
  // Find column indices (flexible matching)
  const findColumn = (names: string[]): number => {
    for (const name of names) {
      const index = headers.findIndex(h => h.includes(name.toLowerCase()));
      if (index !== -1) return index;
    }
    return -1;
  };
  
  const skuIndex = findColumn(['sku', 'sku_code', 'skucode', 'item_code', 'product_code']);
  const statusIndex = findColumn(['status', 'publish_status', 'state']);
  const stockIndex = findColumn(['stock', 'quantity', 'qty', 'inventory', 'stock_quantity']);
  const mainCategoryIndex = findColumn(['main_category', 'maincategory', 'category', 'category1', 'cat1']);
  const subcategoryIndex = findColumn(['sub_category', 'subcategory', 'category2', 'cat2', 'sub_category1']);
  const subSubcategoryIndex = findColumn(['sub_subcategory', 'subsubcategory', 'category3', 'cat3', 'sub_category2']);
  const imageUrlsIndex = findColumn(['image', 'images', 'image_url', 'imageurl', 'image_urls', 'photos', 'media']);
  const contentIndex = findColumn(['content', 'description', 'desc', 'body_html', 'product_description', 'details']);
  
  if (skuIndex === -1) {
    throw new Error('Could not find SKU column. Expected column names: sku, sku_code, item_code, or product_code');
  }
  
  const data: SKUData[] = [];
  
  for (let i = 1; i < lines.length; i++) {
    const values = parseCSVRow(lines[i]);
    
    if (values.length < skuIndex + 1) continue;
    
    const sku = values[skuIndex]?.trim();
    if (!sku) continue;
    
    const status = (statusIndex !== -1 ? values[statusIndex] : '').trim();
    const stock = parseInt(stockIndex !== -1 ? values[stockIndex] : '0') || 0;
    const mainCategory = (mainCategoryIndex !== -1 ? values[mainCategoryIndex] : 'Uncategorized').trim();
    const subcategory = (subcategoryIndex !== -1 ? values[subcategoryIndex] : 'Uncategorized').trim();
    const subSubcategory = (subSubcategoryIndex !== -1 ? values[subSubcategoryIndex] : '').trim();
    const imageUrls = (imageUrlsIndex !== -1 ? values[imageUrlsIndex] : '').trim();
    const content = (contentIndex !== -1 ? values[contentIndex] : '').trim();
    
    // Calculate derived fields
    const imageCount = countImageUrls(imageUrls);
    const has2Images = imageCount >= 2;
    const hasContentFlag = hasContent(content);
    const isSellable = stock > 4;
    
    data.push({
      sku,
      status,
      stock,
      mainCategory,
      subcategory,
      subSubcategory,
      imageUrls,
      content,
      has2Images,
      hasContent: hasContentFlag,
      isSellable
    });
  }
  
  return data;
}

/**
 * Main analysis function
 */
export function analyzeData(data: SKUData[]): AnalyticsData {
  // Remove duplicates based on SKU
  const uniqueData = getUniqueSKUs(data);
  
  const summary = calculateSummary(uniqueData);
  const categoryBreakdown = calculateCategoryBreakdown(uniqueData);
  const issues = identifyIssues(uniqueData, summary);
  const { newSKUs, newSKUData } = detectNewSKUs(uniqueData);
  const newSKUBreakdown = calculateCategoryStats(newSKUData, s => s.mainCategory);
  const movements = detectMovements(uniqueData);
  const uploadHistory = getUploadHistory();
  
  saveSKURecords(uniqueData);
  saveUploadRecord(uniqueData, newSKUs);
  
  return {
    summary,
    categoryBreakdown,
    newSKUBreakdown: {
      mainCategories: newSKUBreakdown,
      subcategories: calculateCategoryStats(newSKUData, s => `${s.mainCategory} > ${s.subcategory}`)
    },
    issues,
    newSKUs,
    newSKUData,
    movements,
    uploadHistory
  };
}

/**
 * Get unique SKUs (first occurrence wins)
 */
function getUniqueSKUs(data: SKUData[]): SKUData[] {
  const skuMap = new Map<string, SKUData>();
  
  data.forEach(item => {
    const sku = item.sku.trim();
    if (sku && !skuMap.has(sku)) {
      skuMap.set(sku, item);
    }
  });
  
  return Array.from(skuMap.values());
}

/**
 * Calculate summary statistics
 * 
 * Formulas:
 * - Total SKUs = Count of unique values in the SKU column
 * - Published = All SKUs where Status = "Publish"
 * - Unpublished = SKUs with Stock < 4 AND Status in (Draft, Private)
 * - Sellable = All SKUs where Stock > 4
 * - SLA Adherence = (SKUs with 2+ images AND content) ÷ Sellable SKUs × 100
 */
function calculateSummary(data: SKUData[]): SummaryStats {
  // Total SKUs = count of unique SKUs in the SKU column
  const totalSKUs = data.length;
  
  // Published = all SKUs where status = "Publish" (exact match)
  const publishedSKUs = data.filter(s => s.status === 'Publish').length;
  
  // Unpublished = SKUs with stock < 4 AND (status = Draft OR status = Private)
  const unpublishedSKUs = data.filter(s => 
    s.stock < 4 && (s.status === 'Draft' || s.status === 'Private')
  ).length;
  
  // Draft = all SKUs with status = "Draft"
  const draftSKUs = data.filter(s => s.status === 'Draft').length;
  
  // Private = all SKUs with status = "Private"
  const privateSKUs = data.filter(s => s.status === 'Private').length;
  
  // Sellable = all SKUs with stock > 4
  const sellableSKUs = data.filter(s => s.stock > 4).length;
  
  // Published AND Sellable
  const publishedAndSellable = data.filter(s => s.status === 'Publish' && s.stock > 4).length;
  
  // SKUs with 2+ images (from sellable SKUs)
  const skusWith2Images = data.filter(s => s.stock > 4 && s.has2Images).length;
  
  // SKUs with content (from sellable SKUs)
  const skusWithContent = data.filter(s => s.stock > 4 && s.hasContent).length;
  
  // SKUs with 2+ images AND content (from sellable SKUs) - for SLA
  const skusWithContentAndImages = data.filter(s => 
    s.stock > 4 && s.has2Images && s.hasContent
  ).length;
  
  const avgStock = totalSKUs > 0 ? Math.round(data.reduce((sum, s) => sum + s.stock, 0) / totalSKUs) : 0;
  
  // SLA Adherence Rate = skusWithContentAndImages / sellableSKUs
  const slaAdherenceRate = sellableSKUs > 0 ? Math.round((skusWithContentAndImages / sellableSKUs) * 100) : 0;
  
  // Image completion rate (from sellable)
  const imageCompletionRate = sellableSKUs > 0 ? Math.round((skusWith2Images / sellableSKUs) * 100) : 0;
  
  // Content rate (from sellable)
  const contentRate = sellableSKUs > 0 ? Math.round((skusWithContent / sellableSKUs) * 100) : 0;
  
  // Publish rate = published / total
  const publishRate = totalSKUs > 0 ? Math.round((publishedSKUs / totalSKUs) * 100) : 0;
  
  return {
    totalSKUs,
    publishedSKUs,
    draftSKUs,
    privateSKUs,
    unpublishedSKUs,
    sellableSKUs,
    publishedAndSellable,
    skusWith2Images,
    skusWithContent,
    skusWithContentAndImages,
    newSKUsThisUpload: 0,
    avgStock,
    imageCompletionRate,
    contentRate,
    slaAdherenceRate,
    publishRate
  };
}

/**
 * Calculate category breakdown
 */
function calculateCategoryBreakdown(data: SKUData[]) {
  const mainCategories = calculateCategoryStats(data, s => s.mainCategory);
  const subcategories = calculateCategoryStats(data, s => `${s.mainCategory} > ${s.subcategory}`);
  const subSubcategories = calculateCategoryStats(data, s => `${s.mainCategory} > ${s.subcategory} > ${s.subSubcategory}`);
  
  return { mainCategories, subcategories, subSubcategories };
}

/**
 * Calculate statistics per category
 */
function calculateCategoryStats(data: SKUData[], getCategory: (s: SKUData) => string): CategoryStats[] {
  const categoryMap = new Map<string, CategoryStats>();
  
  data.forEach(sku => {
    const category = getCategory(sku);
    
    if (!categoryMap.has(category)) {
      categoryMap.set(category, {
        name: category,
        total: 0,
        published: 0,
        draft: 0,
        private: 0,
        unpublished: 0,
        sellable: 0,
        publishedAndSellable: 0,
        skusWith2Images: 0,
        skusWithContent: 0,
        skusWithContentAndImages: 0,
        slaAdherence: 0
      });
    }
    
    const stats = categoryMap.get(category)!;
    stats.total++;
    
    // Published = status is "Publish" (exact match)
    if (sku.status === 'Publish') stats.published++;
    
    // Draft = status is "Draft"
    if (sku.status === 'Draft') stats.draft++;
    
    // Private = status is "Private"
    if (sku.status === 'Private') stats.private++;
    
    // Unpublished = stock < 4 AND (Draft OR Private)
    if (sku.stock < 4 && (sku.status === 'Draft' || sku.status === 'Private')) {
      stats.unpublished++;
    }
    
    // Sellable = stock > 4
    if (sku.stock > 4) {
      stats.sellable++;
      
      // Published AND Sellable
      if (sku.status === 'Publish') {
        stats.publishedAndSellable++;
      }
      
      // Content metrics (only for sellable)
      if (sku.has2Images) stats.skusWith2Images++;
      if (sku.hasContent) stats.skusWithContent++;
      if (sku.has2Images && sku.hasContent) stats.skusWithContentAndImages++;
    }
  });
  
  const results = Array.from(categoryMap.values());
  
  results.forEach(stats => {
    // SLA = skusWithContentAndImages / sellable
    stats.slaAdherence = stats.sellable > 0 
      ? Math.round((stats.skusWithContentAndImages / stats.sellable) * 100) 
      : 0;
  });
  
  return results.sort((a, b) => b.total - a.total);
}

/**
 * Identify issues and insights
 */
function identifyIssues(data: SKUData[], summary: SummaryStats): Issue[] {
  const issues: Issue[] = [];
  
  // Unpublished SKUs (stock < 4 AND Draft/Private)
  if (summary.unpublishedSKUs > 0) {
    issues.push({
      type: 'error',
      title: 'Unpublished SKUs',
      description: `${summary.unpublishedSKUs} SKUs have stock < 4 and are in Draft/Private status - not visible to customers`,
      count: summary.unpublishedSKUs,
      impact: 'These items need stock replenishment or status review to become visible'
    });
  }
  
  // Draft SKUs
  if (summary.draftSKUs > 0) {
    issues.push({
      type: 'warning',
      title: 'Draft SKUs',
      description: `${summary.draftSKUs} SKUs are in Draft status and not published`,
      count: summary.draftSKUs
    });
  }
  
  // Private SKUs
  if (summary.privateSKUs > 0) {
    issues.push({
      type: 'warning',
      title: 'Private SKUs',
      description: `${summary.privateSKUs} SKUs are in Private status`,
      count: summary.privateSKUs
    });
  }
  
  // Missing images (from sellable)
  const missingImages = summary.sellableSKUs - summary.skusWith2Images;
  if (missingImages > 0) {
    issues.push({
      type: 'warning',
      title: 'Missing Images',
      description: `${missingImages} sellable SKUs have fewer than 2 images (URLs separated by comma in image column)`,
      count: missingImages
    });
  }
  
  // Missing content (from sellable)
  const missingContent = summary.sellableSKUs - summary.skusWithContent;
  if (missingContent > 0) {
    issues.push({
      type: 'warning',
      title: 'Missing Content',
      description: `${missingContent} sellable SKUs lack content/description`,
      count: missingContent
    });
  }
  
  // SLA status
  if (summary.slaAdherenceRate >= 80) {
    issues.push({
      type: 'success',
      title: 'SLA Target Met',
      description: `${summary.slaAdherenceRate}% of sellable SKUs meet content standards (2+ images AND content)`,
      count: summary.skusWithContentAndImages
    });
  } else {
    issues.push({
      type: 'info',
      title: 'SLA Below Target',
      description: `Current: ${summary.slaAdherenceRate}%, Target: 80% - ${summary.sellableSKUs - summary.skusWithContentAndImages} SKUs need content improvement`,
      count: summary.sellableSKUs - summary.skusWithContentAndImages
    });
  }
  
  return issues;
}

/**
 * Detect new SKUs compared to previous upload
 */
function detectNewSKUs(data: SKUData[]): { newSKUs: string[]; newSKUData: SKUData[] } {
  const history = getSKURecords();
  const newSKUs: string[] = [];
  const newSKUData: SKUData[] = [];
  
  if (Object.keys(history).length > 0) {
    data.forEach(sku => {
      if (!history[sku.sku]) {
        newSKUs.push(sku.sku);
        newSKUData.push(sku);
      }
    });
  }
  
  return { newSKUs, newSKUData };
}

/**
 * Detect movements (changes) since last upload
 */
function detectMovements(data: SKUData[]): SKUMovement[] {
  const history = getSKURecords();
  const movements: SKUMovement[] = [];
  const currentSKUs = new Set(data.map(s => s.sku));
  
  // Check for status/stock changes and removed SKUs
  Object.entries(history).forEach(([sku, record]) => {
    if (!currentSKUs.has(sku)) {
      // SKU was removed
      movements.push({
        sku,
        previousStatus: record.status,
        currentStatus: 'Removed',
        previousStock: record.stock,
        currentStock: 0,
        mainCategory: record.mainCategory,
        subcategory: record.subcategory,
        movementType: 'removed'
      });
    } else {
      // Check for changes
      const current = data.find(s => s.sku === sku);
      if (current) {
        if (current.status !== record.status) {
          movements.push({
            sku,
            previousStatus: record.status,
            currentStatus: current.status,
            previousStock: record.stock,
            currentStock: current.stock,
            mainCategory: current.mainCategory,
            subcategory: current.subcategory,
            movementType: 'status_change'
          });
        } else if (current.stock !== record.stock) {
          movements.push({
            sku,
            previousStatus: record.status,
            currentStatus: current.status,
            previousStock: record.stock,
            currentStock: current.stock,
            mainCategory: current.mainCategory,
            subcategory: current.subcategory,
            movementType: 'stock_change'
          });
        }
      }
    }
  });
  
  // Check for new SKUs
  data.forEach(sku => {
    if (!history[sku.sku]) {
      movements.push({
        sku: sku.sku,
        previousStatus: 'New',
        currentStatus: sku.status,
        previousStock: 0,
        currentStock: sku.stock,
        mainCategory: sku.mainCategory,
        subcategory: sku.subcategory,
        movementType: 'new'
      });
    }
  });
  
  return movements;
}

/**
 * Get SKU records from localStorage
 */
function getSKURecords(): Record<string, SKURecord> {
  try {
    const stored = localStorage.getItem(STORAGE_KEYS.SKU_HISTORY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (e) {
    console.error('Error reading SKU history:', e);
  }
  return {};
}

/**
 * Save SKU records to localStorage
 */
function saveSKURecords(data: SKUData[]): void {
  const records: Record<string, SKURecord> = {};
  
  data.forEach(sku => {
    records[sku.sku] = {
      sku: sku.sku,
      status: sku.status,
      stock: sku.stock,
      mainCategory: sku.mainCategory,
      subcategory: sku.subcategory,
      imageUrls: sku.imageUrls,
      content: sku.content,
      has2Images: sku.has2Images,
      hasContent: sku.hasContent,
      isSellable: sku.isSellable,
      lastSeen: new Date().toISOString()
    };
  });
  
  try {
    localStorage.setItem(STORAGE_KEYS.SKU_HISTORY, JSON.stringify(records));
  } catch (e) {
    console.error('Error saving SKU history:', e);
  }
}

/**
 * Get upload history from localStorage
 */
function getUploadHistory(): UploadRecord[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEYS.UPLOAD_HISTORY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (e) {
    console.error('Error reading upload history:', e);
  }
  return [];
}

/**
 * Save upload record to localStorage
 */
function saveUploadRecord(data: SKUData[], newSKUs: string[]): void {
  const history = getUploadHistory();
  
  const record: UploadRecord = {
    id: Date.now().toString(),
    fileName: `upload-${new Date().toISOString().split('T')[0]}`,
    uploadDate: new Date().toISOString(),
    totalSKUs: data.length,
    newSKUsCount: newSKUs.length,
    skuList: newSKUs
  };
  
  history.unshift(record);
  
  const trimmed = history.slice(0, 10);
  
  try {
    localStorage.setItem(STORAGE_KEYS.UPLOAD_HISTORY, JSON.stringify(trimmed));
  } catch (e) {
    console.error('Error saving upload history:', e);
  }
}

/**
 * Clear all history
 */
export function clearHistory(): void {
  localStorage.removeItem(STORAGE_KEYS.SKU_HISTORY);
  localStorage.removeItem(STORAGE_KEYS.UPLOAD_HISTORY);
}