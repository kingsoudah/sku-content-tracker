export const STORAGE_KEYS = {
  SKU_HISTORY: 'sku_tracker_history',
  UPLOAD_HISTORY: 'sku_upload_history'
};

export const STATUS_VALUES = {
  PUBLISHED: 'Published',
  DRAFT: 'Draft',
  UNPUBLISHED: 'Unpublished'
};

export const SELLABLE_STOCK_THRESHOLD = 4;

export const SLA_TARGET_PERCENTAGE = 80;